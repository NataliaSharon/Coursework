#pragma once
#include "baseengine.h"

class Demo1Main :
	public BaseEngine
{
public:
	Demo1Main();
	~Demo1Main();

	void SetupBackgroundBuffer();
};

