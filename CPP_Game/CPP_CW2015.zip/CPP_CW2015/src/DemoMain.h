#pragma once
#include "BaseEngine.h"
class DemoMain :
	public BaseEngine
{
public:
	DemoMain();
	~DemoMain();
	void SetupBackgroundBuffer();
};

