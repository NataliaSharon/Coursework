#pragma once
#include "baseengine.h"

class Demo2aMain :
	public BaseEngine
{
public:
	Demo2aMain();
	~Demo2aMain();

	void SetupBackgroundBuffer();
};
